package com.example.crackit;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class MockTestActivity_4_1 extends AppCompatActivity {

    private TextView mockTestTextView;
    private Button startTestButton, downloadPdfButton;
    private String mockTestQuestions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mock_test_4_1);

        mockTestTextView = findViewById(R.id.mockTestTextView);
        startTestButton = findViewById(R.id.startTestButton);
        downloadPdfButton = findViewById(R.id.downloadPdfButton);

        // Get questions from intent and clean up
        mockTestQuestions = getIntent().getStringExtra("mock_test_questions");

        if (mockTestQuestions == null || mockTestQuestions.isEmpty()) {
            Toast.makeText(this, "No test questions available!", Toast.LENGTH_SHORT).show();
            mockTestQuestions = "No questions available.";
        } else {
            mockTestQuestions = cleanQuestions(mockTestQuestions); // Remove answers
        }

        mockTestTextView.setText(mockTestQuestions);

        // Start Test Button - Redirect to ConductTestActivity
        startTestButton.setOnClickListener(v -> {
            if (mockTestQuestions.equals("No questions available.")) {
                Toast.makeText(this, "Cannot start test: No questions available!", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(MockTestActivity_4_1.this, TestTimerActivity_4_2.class);
            intent.putExtra("test_questions", mockTestQuestions);
            startActivity(intent);
        });

        // Download PDF Button - Save test as PDF
        downloadPdfButton.setOnClickListener(v -> saveAsPdf());
    }

    // Function to remove answers & correct text
    private String cleanQuestions(String text) {
        return text.replaceAll("(?i)\\b(correct\\s*answer:\\s*.*)\\b", "") // Remove correct answer
                .replaceAll("(?i)\\b(answer:\\s*.*)\\b", "")  // Remove normal answers
                .replaceAll("\\n\\n+", "\n\n"); // Clean extra spaces
    }

    // Function to save the test as PDF
    private void saveAsPdf() {
        if (mockTestQuestions.equals("No questions available.")) {
            Toast.makeText(this, "Cannot save: No questions available!", Toast.LENGTH_SHORT).show();
            return;
        }

        PdfDocument document = new PdfDocument();
        Paint paint = new Paint();
        paint.setTextSize(16);
        paint.setColor(android.graphics.Color.BLACK);

        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(595, 842, 1).create();
        PdfDocument.Page page = document.startPage(pageInfo);
        Canvas canvas = page.getCanvas();

        int x = 40, y = 50;
        String[] lines = mockTestQuestions.split("\n");

        for (String line : lines) {
            if (y > 800) { // Start a new page if content overflows
                document.finishPage(page);
                pageInfo = new PdfDocument.PageInfo.Builder(595, 842, 1).create();
                page = document.startPage(pageInfo);
                canvas = page.getCanvas();
                y = 50;
            }
            canvas.drawText(line, x, y, paint);
            y += 30;
        }

        document.finishPage(page);
        OutputStream outputStream = null;

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Android 10+ (Scoped Storage)
                ContentResolver resolver = getContentResolver();
                ContentValues contentValues = new ContentValues();
                contentValues.put(MediaStore.MediaColumns.DISPLAY_NAME, "MockTest.pdf");
                contentValues.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf");
                contentValues.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);

                Uri pdfUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues);
                if (pdfUri != null) {
                    outputStream = resolver.openOutputStream(pdfUri);
                }
            } else {
                // Android 9 and below
                File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "MockTest.pdf");
                outputStream = new FileOutputStream(file);
            }

            if (outputStream != null) {
                document.writeTo(outputStream);
                document.close();
                outputStream.close();
                Toast.makeText(this, "PDF saved to Downloads folder!", Toast.LENGTH_LONG).show();
            }
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Failed to save PDF", Toast.LENGTH_SHORT).show();
        }
    }
}
