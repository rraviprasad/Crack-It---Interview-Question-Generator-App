package com.example.crackit;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

public class Splash_screen_Activity_1_1 extends AppCompatActivity {

    private static final int SPLASH_TIME_OUT = 3500; // 2 Seconds delay

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen_1_1);

        // Handler to delay and navigate
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
            boolean isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false);

            if (isLoggedIn) {
                startActivity(new Intent(Splash_screen_Activity_1_1.this, UserDashboard_3_1.class));
            } else {
                startActivity(new Intent(Splash_screen_Activity_1_1.this, login_activity_2_1.class));
            }
            finish();
        }, SPLASH_TIME_OUT);
    }
}
