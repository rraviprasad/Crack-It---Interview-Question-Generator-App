package com.example.crackit;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ConductTestActivity_4_3 extends AppCompatActivity {
    private TextView timerTextView, questionTextView;
    private RadioGroup optionsGroup;
    private RadioButton optionA, optionB, optionC, optionD;
    private Button nextQuestionButton, finishTestButton;
    private CountDownTimer countDownTimer;
    private long timeLeftInMillis;
    private List<QuestionModel> questionList;
    private int currentQuestionIndex = 0;
    private int score = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conduct_test_4_3);

        // Retrieve selected time from Intent
        timeLeftInMillis = getIntent().getLongExtra("time_limit", 300000); // Default: 5 min

        // Initialize UI components
        timerTextView = findViewById(R.id.timerTextView);
        questionTextView = findViewById(R.id.questionTextView);
        optionsGroup = findViewById(R.id.optionsGroup);
        optionA = findViewById(R.id.optionA);
        optionB = findViewById(R.id.optionB);
        optionC = findViewById(R.id.optionC);
        optionD = findViewById(R.id.optionD);
        nextQuestionButton = findViewById(R.id.nextQuestionButton);
        finishTestButton = findViewById(R.id.finishTestButton);

        // Get test questions from Intent
        String mockTestQuestions = getIntent().getStringExtra("mock_test_questions");
        questionList = parseQuestions(mockTestQuestions);

        // Load the first question
        if (!questionList.isEmpty()) {
            loadQuestion(currentQuestionIndex);
        }

        // Start countdown timer
        startTimer();

        // Next question button click event
        nextQuestionButton.setOnClickListener(v -> {
            checkAnswer();
            if (currentQuestionIndex < questionList.size() - 1) {
                currentQuestionIndex++;
                loadQuestion(currentQuestionIndex);
            } else {
                Toast.makeText(this, "All questions answered! Submitting test...", Toast.LENGTH_SHORT).show();
                finishTest();
            }
        });

        // Finish test button click event
        finishTestButton.setOnClickListener(v -> finishTest());
    }

    // Function to parse test questions
    private List<QuestionModel> parseQuestions(String mockTestQuestions) {
        List<QuestionModel> parsedQuestions = new ArrayList<>();
        if (mockTestQuestions == null || mockTestQuestions.isEmpty()) return parsedQuestions;

        String[] questionsArray = mockTestQuestions.split("\n\n");
        for (String questionBlock : questionsArray) {
            String[] lines = questionBlock.split("\n");
            if (lines.length >= 6) {
                String question = lines[0].trim();
                String optionA = lines[1].substring(2).trim();
                String optionB = lines[2].substring(2).trim();
                String optionC = lines[3].substring(2).trim();
                String optionD = lines[4].substring(2).trim();
                String correctAnswer = lines[5].substring(2).trim();

                parsedQuestions.add(new QuestionModel(question, optionA, optionB, optionC, optionD, correctAnswer));
            }
        }
        return parsedQuestions;
    }

    // Load a question into UI
    private void loadQuestion(int index) {
        if (index >= questionList.size()) return;

        QuestionModel currentQuestion = questionList.get(index);
        questionTextView.setText(currentQuestion.getQuestion());
        optionA.setText(currentQuestion.getOptionA());
        optionB.setText(currentQuestion.getOptionB());
        optionC.setText(currentQuestion.getOptionC());
        optionD.setText(currentQuestion.getOptionD());

        optionsGroup.clearCheck();
    }

    // Check answer for current question
    private void checkAnswer() {
        int selectedId = optionsGroup.getCheckedRadioButtonId();
        if (selectedId != -1) {
            RadioButton selectedOption = findViewById(selectedId);
            String userAnswer = selectedOption.getText().toString();

            if (userAnswer.equalsIgnoreCase(questionList.get(currentQuestionIndex).getCorrectAnswer())) {
                score++;
            }
        }
    }

    // Start the countdown timer
    private void startTimer() {
        countDownTimer = new CountDownTimer(timeLeftInMillis, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timeLeftInMillis = millisUntilFinished;
                int minutes = (int) TimeUnit.MILLISECONDS.toMinutes(timeLeftInMillis);
                int seconds = (int) (TimeUnit.MILLISECONDS.toSeconds(timeLeftInMillis) % 60);
                timerTextView.setText(String.format("Time Left: %02d:%02d", minutes, seconds));
            }

            @Override
            public void onFinish() {
                Toast.makeText(ConductTestActivity_4_3.this, "Time's Up! Submitting Test...", Toast.LENGTH_SHORT).show();
                finishTest();
            }
        }.start();
    }

    // Submit the test
    private void finishTest() {
        countDownTimer.cancel();
        Intent intent = new Intent(ConductTestActivity_4_3.this, ResultTestActivity.class);
        intent.putExtra("final_score", score);
        intent.putExtra("total_questions", questionList.size());
        startActivity(intent);
        finish();
    }
}
