package com.example.crackit;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class UserDashboard_3_1 extends AppCompatActivity {

    private static final String API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent?key=";
    private String apiKey;
    private EditText topicEditText;
    private Button generateMockTestButton;
    private Spinner questionCountSpinner, levelSpinner;
    private ProgressBar progressBar;

    private String selectedQuestionCount, selectedLevel;
    private OkHttpClient client = new OkHttpClient();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_dashboard_3_1);

        initializeUI();
        setupSpinners();
        setupGenerateMockTestButton();
    }

    private void initializeUI() {
        apiKey = getString(R.string.gemini_api_key);

        // Initialize Toolbar and set it as the ActionBar
        Toolbar toolbar = findViewById(R.id.toolbar);
        if (toolbar != null) {
            setSupportActionBar(toolbar);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("User Dashboard");
        } else {
            Toast.makeText(this, "Toolbar not found!", Toast.LENGTH_SHORT).show();
        }

        topicEditText = findViewById(R.id.inputTopic);
        generateMockTestButton = findViewById(R.id.generateMockTestButton);
        questionCountSpinner = findViewById(R.id.questionCountSpinner);
        levelSpinner = findViewById(R.id.levelSpinner);
        progressBar = findViewById(R.id.progressBar1);
    }

    private void setupSpinners() {
        setupSpinner(questionCountSpinner, R.array.question_count_options);
        setupSpinner(levelSpinner, R.array.test_level_options);
    }

    private void setupSpinner(Spinner spinner, int arrayResId) {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, arrayResId, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (spinner == questionCountSpinner) {
                    selectedQuestionCount = parent.getItemAtPosition(position).toString();
                } else {
                    selectedLevel = parent.getItemAtPosition(position).toString();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });
    }

    private void setupGenerateMockTestButton() {
        generateMockTestButton.setOnClickListener(v -> {
            String topic = topicEditText.getText().toString().trim();

            if (topic.isEmpty() || selectedQuestionCount == null || selectedLevel == null) {
                Toast.makeText(this, "Please fill all fields!", Toast.LENGTH_SHORT).show();
            } else {
                generateMockTest(topic, selectedQuestionCount, selectedLevel);
            }
        });
    }

    private void generateMockTest(String topic, String questionCount, String level) {
        progressBar.setVisibility(View.VISIBLE);
        generateMockTestButton.setEnabled(false);

        String apiUrl = API_URL + apiKey;

        try {
            JSONObject requestBody = new JSONObject();
            JSONArray contentsArray = new JSONArray();
            JSONObject contentObject = new JSONObject();
            contentObject.put("role", "user");
            contentObject.put("parts", new JSONArray().put(new JSONObject().put("text",
                    "Generate " + questionCount + " multiple-choice questions on '" + topic + "' at " + level + " level. " +
                            "Each question should have four options labeled A, B, C, and D. Include the correct answer.")
            ));

            contentsArray.put(contentObject);
            requestBody.put("contents", contentsArray);

            RequestBody body = RequestBody.create(requestBody.toString(), MediaType.get("application/json; charset=utf-8"));
            Request request = new Request.Builder().url(apiUrl).post(body).build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    runOnUiThread(() -> handleFailure());
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    runOnUiThread(() -> handleSuccess(response));
                }
            });

        } catch (JSONException e) {
            runOnUiThread(() -> Toast.makeText(this, "Error forming request!", Toast.LENGTH_SHORT).show());
        }
    }

    private void handleFailure() {
        progressBar.setVisibility(View.GONE);
        generateMockTestButton.setEnabled(true);
        Toast.makeText(this, "Failed to generate test. Check internet!", Toast.LENGTH_SHORT).show();
    }

    private void handleSuccess(Response response) {
        progressBar.setVisibility(View.GONE);
        generateMockTestButton.setEnabled(true);

        try {
            String responseBody = response.body().string();
            JSONObject jsonResponse = new JSONObject(responseBody);
            JSONArray candidates = jsonResponse.optJSONArray("candidates");

            if (candidates != null && candidates.length() > 0) {
                JSONObject candidate = candidates.getJSONObject(0);
                JSONObject contentObject = candidate.optJSONObject("content");

                if (contentObject != null) {
                    JSONArray parts = contentObject.optJSONArray("parts");
                    if (parts != null && parts.length() > 0) {
                        String mockTestQuestions = parts.getJSONObject(0).optString("text").replaceAll("\\*", "").trim();
                        redirectToMockTestActivity(mockTestQuestions);
                    }
                }
            }
        } catch (IOException | JSONException e) {
            Toast.makeText(this, "Error processing response!", Toast.LENGTH_SHORT).show();
        }
    }

    private void redirectToMockTestActivity(String mockTestQuestions) {
        Intent intent = new Intent(this, MockTestActivity_4_1.class);
        intent.putExtra("mock_test_questions", mockTestQuestions);
        startActivity(intent);
    }
}
