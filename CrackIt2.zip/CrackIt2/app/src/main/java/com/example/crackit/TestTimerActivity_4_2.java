package com.example.crackit;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class TestTimerActivity_4_2 extends AppCompatActivity {
    private EditText timeInput;
    private Button startTestButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_test_4_2);

        timeInput = findViewById(R.id.timeInput);
        startTestButton = findViewById(R.id.startTestButton);

        startTestButton.setOnClickListener(v -> {
            String timeText = timeInput.getText().toString().trim();

            if (timeText.isEmpty()) {
                Toast.makeText(this, "Please enter time in minutes!", Toast.LENGTH_SHORT).show();
                return;
            }

            int timeInMinutes;
            try {
                timeInMinutes = Integer.parseInt(timeText);
                if (timeInMinutes <= 0) {
                    Toast.makeText(this, "Time must be greater than 0 minutes!", Toast.LENGTH_SHORT).show();
                    return;
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Invalid input! Enter a valid number.", Toast.LENGTH_SHORT).show();
                return;
            }

            long timeInMillis = timeInMinutes * 60 * 1000;

            // Redirect to ConductTestActivity_4_3 with selected time
            Intent intent = new Intent(TestTimerActivity_4_2.this, ConductTestActivity_4_3.class);
            intent.putExtra("time_limit", timeInMillis);
            startActivity(intent);
            finish(); // Close this activity
        });
    }
}
