package com.example.crackit;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class UserSignupActivity_2_2 extends AppCompatActivity {

    private EditText emailEditText, passwordEditText;
    private Button registerButton;
    private TextView loginRedirectTextView;  // Fixed to use TextView
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_signup_2_2);

        // Initialize UI components
        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        registerButton = findViewById(R.id.registerButton);
        loginRedirectTextView = findViewById(R.id.signUpTextView);  // Fixed ID

        dbHelper = new DBHelper(this);

        // Check if database is connected
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        if (db != null) {
            Toast.makeText(this, "Database connected!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Database failed to connect!", Toast.LENGTH_SHORT).show();
        }

        // Register Button Click Listener
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = emailEditText.getText().toString().trim();
                String password = passwordEditText.getText().toString().trim();

                if (email.isEmpty() || password.isEmpty()) {
                    Toast.makeText(UserSignupActivity_2_2.this, "Please enter all details", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean isRegistered = dbHelper.registerUser(email, password);
                if (isRegistered) {
                    Toast.makeText(UserSignupActivity_2_2.this, "User Registered Successfully!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(UserSignupActivity_2_2.this, login_activity_2_1.class));
                    finish();
                } else {
                    Toast.makeText(UserSignupActivity_2_2.this, "User already exists or registration failed!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        // Redirect to Login Page
        loginRedirectTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UserSignupActivity_2_2.this, login_activity_2_1.class));
                finish();
            }
        });
    }
}
